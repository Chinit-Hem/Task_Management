package com.example.taskmanagement

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
